package project.electronic_vehicle_charging;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Electronic_Vehicle_Charging_ApplicationTests {

	@Test
	void contextLoads() {
	}

}
