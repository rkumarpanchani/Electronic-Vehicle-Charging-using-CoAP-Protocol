/***
 * Creating a package for Electronic Vehicle Charging project
 */
package project.electronic_vehicle_charging;

/***
 * Importing the spring boot frameworks
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/***
 * Created a class called IoT_Gateway_Application. Since, I am using Spring Boot Framework, which is used to reduce Development, Unit Test and Integration Test time and to ease the development of Production ready web applications very easily compared to existing Spring Framework, which really takes more time. 
 * Spring Boot Framework can use to create stand-alone Java applications, which includes an embedded Tomcat(or Jetty) server. No need to maintain xml files.
 * @author Ramesh Kumar
 */
@SpringBootApplication
public class IoT_Gateway_Application {
	/***
	 * Executing the project, by calling it in the main. 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(IoT_Gateway_Application.class, args);
	}
}