/***
 * Creating a package for Electronic Vehicle Charging project
 */
package project.electronic_vehicle_charging;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/***
 * Created a class called IoT_Gateway_Controller. Along with this, I am using important annotations.
 * Annotation @controller means, where you can implement different methods and you can access them by using different HTTP requests. 
 * Annotation @RestController (used for RESTFul web services) means, where you can implement REST based APIs.
 * Annotation @RestController = @Controller + @ResponseBody
 * @author Ramesh Kumar
 */
@RestController
public class IoT_Gateway_Controller {
	
	/***
	 * @RequestMapping annotation is used for mapping web requests to particular handler classes or handler methods. This annotation maps HTTP requests to handler methods of MVC and REST controllers.
	 * value: URL that needs to be called to invoke the method 
	 * produces: what the method will return e.g XML, JSON etc. In this case it will return application/xml
	 * @return
	 */
	@RequestMapping(value = "/getSensorData", produces = "application/xml")
	/***
	 * Here, I wrote getSensorData() method and this is our first Sensor. This sensor is working on port number 5683. The sensor output is in JSON format, which is converted to XML format. So that it can communicate with the HTTP, which understand XML format.
	 * In CoAP the default port is assumed to be 5683 with UDP Protocol.  
	 * @return
	 */
	public String getSensorData() {
		String xml = "";
		CoapClient client = new CoapClient("coap://localhost:5683/getSensorData");
        CoapResponse response1 = client.get();
        if (response1!=null) {        
        	System.out.println( response1.getCode() );
        	System.out.println( response1.getOptions() ); 
        	System.out.println( response1.getResponseText() );
        	JSONObject json = new JSONObject(response1.getResponseText());
        	xml = XML.toString( json );
        	System.out.println( xml );        	
        }
        else {        	
        	System.out.println("Oops request failed :(");        	
        }
        return xml;
	}
	
	/***
	 * value: URL that needs to be called to invoke the method. In this case, it will invoke getSensor2Data method 
	 * produces: what the method will return e.g XML, JSON etc. In this case it will return application/xml format output.
	 * @return
	 */
	@RequestMapping(value = "/getSensor2Data", produces = "application/xml")
	/***
	 * Here, I wrote getSensor2Data() method and this is our second Sensor. This sensor is working on port number 5685. The sensor output is in JSON format, which is converted to XML format. So that it can communicate with the HTTP, which understand XML format.
	 * @return
	 */
	public String getSensor2Data() {
		String xml = "";
		CoapClient client = new CoapClient("coap://localhost:5685/getSensor2Data");
        CoapResponse response1 = client.get();
        if (response1!=null) {        
        	System.out.println( response1.getCode() );
        	System.out.println( response1.getOptions() );
        	System.out.println( response1.getResponseText() );
        	JSONObject json = new JSONObject(response1.getResponseText());
        	xml = XML.toString( json );
        	System.out.println( xml );        	
        }
        else {        	
        	System.out.println("Oops request failed :(");        	
        }
        return xml;
	}
	
	/***
	 * value: In this case, it will invoke setSensorData method, which will trigger to our first actuator.  
	 * produces: what the method will return e.g XML, JSON etc. In this case it will return application/xml format output.
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/setSensorData", consumes = "application/xml")
	/***
	 * * Here, I wrote down the logic for my first used case of electronic vehicle charging project. It will set the values in actuator and after sometime sensor will access that information.
	 * //key: "SensorDataFinal" -> in order to access this key, we need to define this in our actuator as well. Otherwise, we can't communicate with actuator. 
	 * @param xml
	 */
	public void setSensorData(@RequestBody String xml) {
		CoapClient client = new CoapClient("coap://localhost:5690/setSensorData");
		JSONObject json = XML.toJSONObject(xml);
		if(json.getInt("SensorData")>=13 && json.getInt("SensorData")<=18) {
			json.put("SensorDataFinal", "Charging via Solar Panel"); 
		}
		else if (json.getInt("SensorData")>=0 && json.getInt("SensorData")<13) {
			json.put("SensorDataFinal", "Charging via Home Electricity");
		}
		else if (json.getInt("SensorData")>18 && json.getInt("SensorData")<=24) {
			json.put("SensorDataFinal", "Charging via Home Electricity"); 
		}
		else {
			json.put("SensorDataFinal", "Incorrect input");
		}
		System.out.println( xml );		
		System.out.println( json );
        CoapResponse response2 = client.post(json.toString(), MediaTypeRegistry.APPLICATION_JSON);
        if (response2!=null) {        
        	System.out.println( response2.getCode() );
        	System.out.println( response2.getOptions() );
        	System.out.println( response2.getResponseText() );        	
        }
        else {        	
        	System.out.println("Oops request failed :(");        	
        }
	}
	
	/***
	 * value: In this case, it will invoke setSensor2Data method, which will trigger to our second actuator.  
	 * produces: what the method will return e.g XML, JSON etc. In this case it will return application/xml format output.
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/setSensor2Data", consumes = "application/xml")
	/***
	 * * Here, I wrote down the logic for my second used case of electronic vehicle charging project. It will set the values in actuator and after sometime sensor will access that information.
	 * //key: "SensorDataFinal_2" -> in order to access this key, we need to define this in our second actuator as well. Otherwise, we can't communicate with actuator. 
	 * @param xml
	 */
	public void setSensor2Data(@RequestBody String xml) {
		CoapClient client = new CoapClient("coap://localhost:5686/setSensor2Data");
		JSONObject json = XML.toJSONObject(xml);
		if(json.getInt("Sensor2Data")>=30 && json.getInt("Sensor2Data")<=100) {
			json.put("SensorDataFinal_2", "Emergency Charging Turned ON"); //key: "SensorDataFinal"  
		}
		else if (json.getInt("Sensor2Data")<30 && json.getInt("Sensor2Data")>=0) {
			json.put("SensorDataFinal_2", "Emergency Charging Turned OFF"); //key: "SensorDataFinal" 
		}
		else {
			json.put("SensorDataFinal_2", "Incorrect input"); //key: "SensorDataFinal"
		}
		System.out.println( xml );		
		System.out.println( json );
        CoapResponse response2 = client.post(json.toString(), MediaTypeRegistry.APPLICATION_JSON);
        if (response2!=null) {        
        	System.out.println( response2.getCode() );
        	System.out.println( response2.getOptions() );
        	System.out.println( response2.getResponseText() );        	
        }        
        else {        	
        	System.out.println("Oops request failed :(");        	
        }
	}
}