/***
 * Creating a sub-package for Electronic Vehicle Charging project for the sensor
 */
package project.electronic_vehicle_charging.Sensors;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.springframework.stereotype.Component;

/***
 * Spring Component annotation is used to denote a class as Component. 
 * It means that Spring framework will auto-detect these classes for dependency injection when annotation-based configuration and classpath scanning is used.
 * I wrote the code in class Smartly_Sensor_Get_Battery_Status.
 * @author Ramesh Kumar
 */
@Component
public class Smartly_Sensor_Get_Battery_Status {
	/***
	 * Here, I declared a method called Smartly_Sensor_Get_Battery_Status() and I defined an instance of class CoapServer and declared server as an object.
	 * Here, the sensor will set the handle get requests. The sensor is defined on default port i.e. 5683 and sensor will get the data from actuator.    
	 */
	public Smartly_Sensor_Get_Battery_Status() {
		CoapServer server = new CoapServer();
		server.add(new GetSensorData());       
        server.start(); 
	}
	
	/***
	 * Here class GetSensorData is extending the CoapResource.
	 * CoapResource uses four distinct methods to handle requests: handleGET(), handlePOST(), handlePUT() and handleDELETE().
	 * Here, we have sensor, therefore, it will handleGET() requests. 
	 * @author Ramesh Kumar
	 */
	public static class GetSensorData extends CoapResource {
        public GetSensorData() {
            super("getSensorData");
            getAttributes().setTitle("Get Sensor Data");
        }

        /***
         * Here, the sensor will handle the GET requests. And I am writing into the text file "For_Actuator_And_Sensor_1.txt". 
         * The data text file is used to write the content using the BufferedWriter class in the text file. And data will be read by the sensor using the BufferedReader class.
         * If there is any error then it would throw the exception. Meaning that, it will write 25 in the text file as default.
         * @override annotation is used to override the content in the existing class. 
         */
        @Override
        public void handleGET(CoapExchange exchange) {
        	StringBuilder sb = new StringBuilder();
        	BufferedWriter bw = null;        	
        	BufferedReader br = null;
        	if(!(new File("For_Actuator_And_Sensor_1.txt")).exists())
        	{
        		try {
    	        	bw = new BufferedWriter(new FileWriter(new File("For_Actuator_And_Sensor_1.txt")));
    	            bw.write("Battery charging mode");
    	        }

    	        catch (IOException e) {
    	            System.err.format("IOException: %s%n", e);
    	        }
    	        
    	        finally {
    	        	try {
    					bw.close();
    				} catch (IOException e) {
    					e.printStackTrace();
    				}
    	        }        		
        	}

            try {            	
            	br = Files.newBufferedReader(Paths.get("For_Actuator_And_Sensor_1.txt").toAbsolutePath());

                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
            } 
            
            catch (IOException e) {
                System.err.format("IOException: %s%n", e);
            }
            
            finally {
            	try {
    				br.close();
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
            }
            System.out.println(sb);   	
            exchange.respond(ResponseCode.CONTENT, "{\"SensorData\":" + sb + "}", MediaTypeRegistry.APPLICATION_JSON);
        }
    }
}