/***
 * Creating a sub-package for Electronic Vehicle Charging project for the actuator 02
 */
package project.electronic_vehicle_charging.Actuators;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

/***
 * Spring Component annotation is used to denote a class as Component. 
 * It means that Spring framework will auto-detect these classes for dependency injection when annotation-based configuration and classpath scanning is used.
 * @author Ramesh Kumar
 */
@Component
public class Smartly_Vehicle_Usage_In_Emergency_Case {
	/***
	 * Here, I declared a method called Smartly_Vehicle_Usage_In_Emergency_Case() and I defined an instance of class CoapServer and declared server as an object.
	 * Here, actuator will set the handle post requests. The actuator is defined on coap server port 5686 and it set the sensor 02 data here.    
	 */
	public Smartly_Vehicle_Usage_In_Emergency_Case() {
		CoapServer server = new CoapServer(5686);
		server.add(new SetSensor2Data());       
        server.start();
	}
	
	
	/***
	 * Here class SetSensor2Data is extending the CoapResource.
	 * CoapResource uses four distinct methods to handle requests: handleGET(), handlePOST(), handlePUT() and handleDELETE().
	 * Here, we have actuator, therefore, it will handlePOST() requests. 
	 * @author Ramesh Kumar
	 */
	public static class SetSensor2Data extends CoapResource {
        public SetSensor2Data() {
            super("setSensor2Data");
            getAttributes().setTitle("Set Sensor2 Data");
        }

        /***
         * Here, the actuator will handle the POST requests. And I am writing into the text file "For_Actuator_And_Sensor_2.txt". 
         * The data text file is used to write the content using the BufferedWriter class in the text file.
         * If there is any error then it would throw the exception.
         * @override annotation is used to override the content in the existing class. 
         */
        @Override
        public void handlePOST(CoapExchange exchange) {	
			System.out.println(exchange.getRequestText());			
			exchange.respond(ResponseCode.CONTENT, "{\"message\":\"POST_REQUEST_SUCCESS\"}", MediaTypeRegistry.APPLICATION_JSON);
			JSONObject json = new JSONObject(exchange.getRequestText());
			String data = json.get("SensorDataFinal_2").toString();			
			BufferedWriter bw = null;
	        try {
	        	bw = new BufferedWriter(new FileWriter(new File("For_Actuator_And_Sensor_2.txt")));
	            bw.write(data);
	        }
	        catch (IOException e) {
	            System.err.format("IOException: %s%n", e);
	        }
	        finally {
	        	try {
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
	        }
		}
    }
}